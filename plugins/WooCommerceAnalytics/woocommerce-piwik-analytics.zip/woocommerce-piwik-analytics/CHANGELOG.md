1.0.15
- Fix product cart coupon might not be applied when using WooCommerce Subscriptions 

1.0.13
- Make sure there is no error should Woocommerce not be installed
- Remove potential double slashes in a URL
- Update tested to version number

1.0.12
- Compatibility with Protect idSite

1.0.11
- Update tested up to Woocommerce version

1.0.10
- Renamed some more Piwik wordings to Matomo
- Updated log file name from Piwik to Matomo

1.0.9
- Updated compatibility with WooCommerce 3.3.0

1.0.8
- Renamed Piwik to Matomo 

1.0.7
- Respect a configured user role tracking filter in WP-Piwik plugin.
- Track order number instead of order id if they are different

1.0.6
- Better compatibility with "Subscribe all the things" and possibly other plugins.
- Anonymize token_auth in log

1.0.5
- Support for WPML
- List compatible WooCommerce versions

1.0.4
- Validate Piwik configuration and API token daily

1.0.3
- Better compatibility with some payment providers that redirect to complete payment

1.0.2
- Make sure to track orders that don't need a payment eg when they are paid via cheque or cash on pick up
- Easier token auth configuration when copying the token directly from Piwik

1.0.1
- Remove unneeded re-calculation of total values after an order

1.0.0
- Initial version
