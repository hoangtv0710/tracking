<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik\Admin;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Tracking\Tracker;
use WooPiwik;
use WC_Admin_Settings;

include_once __DIR__ . '/../../../../woocommerce/includes/admin/settings/class-wc-settings-page.php';

class Settings extends \WC_Settings_Page {

    const FIELD_PIWIK_URL = 'woopiwik_piwik_url';
    const FIELD_PIWIK_IDSITE = 'woopiwik_piwik_idsite';
    const FIELD_TRACKING_ENABLED = 'woopiwik_tracking_enabled';
    const FIELD_PIWIK_TOKEN_AUTH = 'woopiwik_piwik_tokenauth';
    const FIELD_TRACKING_COOKIE_DOMAIN = 'woopiwik_tracking_cookiedomain';
    const FIELD_LOGGING = 'woopiwik_logging';

    /**
     * Settings are valid if either tracking is not activated, or if tracking is activated and a Matomo IdSite and
     * tracking URL is configured. The tracking URL has to be an actual Matomo URL. Settings are not valid if tracking
     * is activated but tracking URL or idSite is not configured or when the configured tracking URL is not an actual
     * Matomo tracking URL.
     */
    const VALID_SETTINGS = 'woopiwik_settings_valid';

    const MESSAGE_INVALID_SETTINGS = 'Woo-Matomo is not correctly configured. To fix this error either deactivate tracking or change the Matomo Instance configuration.';
    const MESSAGE_INVALID_TOKEN = 'Woo-Matomo is not correctly configured. The authentication token needs to be 32 characters.';

    /**
     * Init and hook in the integration.
     */
    public function __construct($registerEvents = true) {
        if ($registerEvents) {
            $this->id    = 'woopiwik';
            $this->label = 'Matomo';

            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_URL, array($this, 'sanitizePiwikUrl'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_IDSITE, array($this, 'sanitizePiwikIdSite'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_TOKEN_AUTH, array($this, 'trimTextField'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_TRACKING_COOKIE_DOMAIN, array($this, 'trimTextField'), 20, $args = 1);

            parent::__construct();
        }
    }

    /**
     * Get sections.
     *
     * @return array
     */
    public function get_sections() {
        $sections = array(
            '' => 'Woocommerce Matomo Analytics Options'
        );

        return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
    }

    public function output()
    {
        echo '<h1>WooCommerce Matomo Analytics</h1>';
        echo '<p>' . sprintf(__('Here you can configure the WooCommerce Matomo (formerly Piwik) tracking. When activated, this plugin will track Ecommerce activities such as purchases and cart updates to make sure you have accurate Ecommerce data tracked in your Matomo. To track regular pageviews, outlinks, downloads and more it is still needed to include the Matomo tracking code into your website. For this we recommend using the WP-Matomo/WP-Piwik plugin. %5$sThis plugin is built and maintained by %1$sInnoCraft%2$s, the creators of %3$sMatomo Analytics%4$s. We help our clients get started, configure, monitor and make the most of their Matomo analytics service. We also offer unique analytics products and services that help grow your business and meet the needs of small, medium and large businesses alike.%6$sDon\'t have a Matomo (Piwik) yet? You can either self host Matomo on premise, or take away all the hassle with our %7$sMatomo Analytics Cloud%8$s.', 'woocommerce-piwik-analytics'), '<a href="https://www.innocraft.com">', '</a>', '<a href="https://matomo.org">', '</a>', '<br /><br />', '<br /><br />', '<a href="https://www.innocraft.cloud">', '</a>') . '</p>';

        parent::output();
    }

    /**
     * Get settings array.
     *
     * @return array
     */
    public function get_settings() {
        $settings = apply_filters( 'woo_piwik_settings', array(

            array('title' => __('Matomo Instance', 'woocommerce-piwik-analytics'), 'type' => 'title',
                  'desc' => __('This section lets you configure the Matomo instance the Ecommerce data should be tracked into. All fields need to be defined.', 'woocommerce-piwik-analytics'),
                  'id' => 'woopiwik_piwikinstance_settings' ),

            array(
                'title'       => __('Matomo URL', 'woocommerce-piwik-analytics'),
                'desc'        => __('Enter your Matomo URL. This is the same URL you use to access your Matomo (or Piwik) instance, e.g. https://example.com/matomo/.', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_PIWIK_URL,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => 'https://www.example.com/matomo',
                'default'     => '',
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                'title'       => __('Matomo Site ID', 'woocommerce-piwik-analytics'),
                'desc'        => __('Enter the Piwik Site ID for this website. It is an integer, e.g. 1 or 42.', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_PIWIK_IDSITE,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => '',
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                 'title'       => __('Matomo Auth Token', 'woocommerce-piwik-analytics'),
                 'desc_tip'    => __('Enter the Matomo Auth-Token of a user with at least Write-access (Admin access if you use Matomo 3.5 or older). It is an alphanumerical code like 0a1b2c34d56e78901fa2bc3d45678efa.', 'woocommerce-piwik-analytics'),
                 'desc'        => sprintf(__('See %1$sMatomo FAQ%2$s. The Matomo user needs at least %3$sWrite-access%4$s.', 'woocommerce-piwik-analytics'), '<a href="https://matomo.org/faq/general/faq_114/" target="_blank" rel="noopener noreferrer">', '</a>', '<strong>', '</strong>'),
                 'id'          => self::FIELD_PIWIK_TOKEN_AUTH,
                 'type'        => 'password',
                 'css'         => 'min-width:300px;',
                 'placeholder' => __( 'N/A', 'woocommerce' ),
                 'default'     => '',
                 'autoload'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_piwikinstance_settings'),

            array('title' => __('Tracking', 'woocommerce-piwik-analytics'), 'type' => 'title',
                  'desc' => '',
                  'id' => 'woopiwik_tracking_settings'),

            array(
                'title'       => __('Enabled', 'woocommerce-piwik-analytics'),
                'desc'        => __('Track Ecommerce orders and cart updates', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_TRACKING_ENABLED,
                'type'        => 'checkbox',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => false,
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                'title'       => __('Cookie Domain', 'woocommerce-piwik-analytics'),
                'desc_tip'    => sprintf(__('Needs to be only specified if you use a custom cookie domain in the JavaScript tracker via "%1$s". Usually does not need to be specified. If specified, make sure to specify same domain as specifed via JavaScript.', 'woocommerce-piwik-analytics'), "_paq.push(['setCookieDomain', '...'])"),
                'desc'        => __('Optional', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_TRACKING_COOKIE_DOMAIN,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => '',
                'autoload'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_tracking_settings'),

            array('title' => __('General', 'woocommerce-piwik-analytics'), 'type' => 'title',
                'desc' => '',
                'id' => 'woopiwik_general_settings' ),

            array(
                'title'       => __('Enable Logging', 'woocommerce-piwik-analytics'),
                'desc'        => __('If enabled, logs all tracked data into log files located in "wp-content/uploads/wc-logs".', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_LOGGING,
                'type'        => 'checkbox',
                'default'     => true,
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_general_settings'),

        ) );

        return apply_filters('woocommerce_get_settings_' . $this->id, $settings);
    }

    public static function canTrack()
    {
        $trackingEnabled = get_option(self::FIELD_TRACKING_ENABLED);

        if (empty($trackingEnabled) || $trackingEnabled === 'no') {
            return false;
        }

        return (bool) get_option(self::VALID_SETTINGS, false);
    }

    public function save()
    {
        parent::save();
        $this->validate_settings();
    }

    public function validate_settings()
    {
        $url = get_option(self::FIELD_PIWIK_URL);
        $idSite = get_option(self::FIELD_PIWIK_IDSITE);
        $token = get_option(self::FIELD_PIWIK_TOKEN_AUTH);
        $activated = get_option(self::FIELD_TRACKING_ENABLED);

        if (!empty($activated) && $activated !== 'no') {
            if (!empty($url) && !empty($idSite) && !empty($token) && is_string($token) && strlen($token) > 30 && ctype_alnum($token)) {
	            $valid = 1;
            } else {
	            $valid = 0;
            }
            if ($valid && is_numeric($idSite)) {
		// we only validate token when idSite is numeric, if protectTrackId is used, we assume it is valid as the
		// ping method otherwise won't work
                $tracker = new Tracker();
                $valid = $tracker->ping();
            }
		
            if (!$valid) {
                if (strlen($token) !== 32) {
                    WC_Admin_Settings::add_error(self::MESSAGE_INVALID_TOKEN);
                } else {
                    WC_Admin_Settings::add_error(self::MESSAGE_INVALID_SETTINGS);
                }
            }
            update_option(self::VALID_SETTINGS, (int) $valid, $autoload = true);
        } else {
            update_option(self::VALID_SETTINGS, 1, $autoload = true);
        }
    }

    public function sanitizePiwikUrl($value)
    {
        if (!empty($value) && is_string($value)) {
            $value = trim($value);
            if (strpos($value, '://') === false) {
                $value = 'http://' . $value;
            }
            $value = rtrim($value, '/');
        }

        return $value;
    }

    public function sanitizePiwikIdSite($value)
    {
        if (!empty($value) || $value === '0') {
            return $value;
        }

        return '';
    }

    public function trimTextField($value)
    {
        if (!empty($value) && is_string($value)) {
            $value = trim($value);
            $value = str_replace('&token_auth=', '', $value);
            $value = str_replace('token_auth=', '', $value);
            $value = str_replace('=', '', $value);
        }

        return $value;
    }


}
